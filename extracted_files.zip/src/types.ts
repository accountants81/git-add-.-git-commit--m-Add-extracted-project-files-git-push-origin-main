export interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  description: string;
  category: string;
  sizes: string[];
  colors: string[];
  rating: number;
  discount: number;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export interface OrderDetails {
  name: string;
  phone: string;
  address: string;
  governorate: string;
  notes?: string;
  items: CartItem[];
  total: number;
  shipping: number;
}