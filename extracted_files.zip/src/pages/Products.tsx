import React, { useState } from 'react';
import { products, categories } from '../data/products';
import { useCart } from '../context/CartContext';

export default function Products() {
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const { addToCart } = useCart();

  const filteredProducts = selectedCategory
    ? products.filter(p => p.category === selectedCategory)
    : products;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-wrap gap-4 mb-8">
        <button
          onClick={() => setSelectedCategory('')}
          className={`px-4 py-2 rounded-lg ${
            selectedCategory === '' ? 'bg-olive-600 text-white' : 'bg-gray-800 text-olive-600'
          }`}
        >
          الكل
        </button>
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-lg ${
              selectedCategory === category ? 'bg-olive-600 text-white' : 'bg-gray-800 text-olive-600'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredProducts.map(product => (
          <div key={product.id} className="bg-gray-900 rounded-lg shadow-md overflow-hidden">
            <img src={product.image} alt={product.name} className="w-full h-64 object-cover" />
            <div className="p-4">
              <h3 className="font-semibold text-lg mb-2 text-olive-600">{product.name}</h3>
              <p className="text-olive-400 mb-4">{product.description}</p>
              <div className="flex justify-between items-center">
                <span className="font-bold text-lg text-olive-600">{product.price} ج.م</span>
                <button
                  onClick={() => addToCart(product)}
                  className="bg-olive-600 text-white px-4 py-2 rounded hover:bg-olive-700"
                >
                  إضافة للسلة
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}