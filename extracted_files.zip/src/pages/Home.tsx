import React from 'react';
import { Link } from 'react-router-dom';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';
import { Star } from 'lucide-react';
import { products } from '../data/products';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

export default function Home() {
  const featuredProducts = products.slice(0, 4);
  const discountedProducts = products.filter(p => p.discount > 0);

  return (
    <div className="space-y-12 py-8">
      {/* Hero Slider */}
      <Swiper
        modules={[Autoplay, Navigation, Pagination]}
        navigation
        pagination={{ clickable: true }}
        autoplay={{ delay: 5000 }}
        className="h-[500px]"
      >
        <SwiperSlide>
          <div className="relative h-full bg-gray-900">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1441984904996-e0b6ba687e04')] bg-cover bg-center opacity-50"></div>
            <div className="relative max-w-7xl mx-auto px-4 h-full flex items-center">
              <div className="text-white">
                <h1 className="text-4xl md:text-6xl font-bold mb-4">أناقة الرجل العصري</h1>
                <p className="text-xl mb-8">اكتشف أحدث تشكيلات الملابس الرجالية العالمية</p>
                <Link
                  to="/products"
                  className="bg-white text-gray-900 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition"
                >
                  تسوق الآن
                </Link>
              </div>
            </div>
          </div>
        </SwiperSlide>
        <SwiperSlide>
          <div className="relative h-full bg-gray-900">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1490367532201-b9bc1dc483f6')] bg-cover bg-center opacity-50"></div>
            <div className="relative max-w-7xl mx-auto px-4 h-full flex items-center">
              <div className="text-white">
                <h1 className="text-4xl md:text-6xl font-bold mb-4">خصومات حصرية</h1>
                <p className="text-xl mb-8">وفر حتى 50% على تشكيلة مختارة</p>
                <Link
                  to="/products"
                  className="bg-white text-gray-900 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition"
                >
                  تسوق العروض
                </Link>
              </div>
            </div>
          </div>
        </SwiperSlide>
      </Swiper>

      {/* Featured Products */}
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">منتجات مميزة</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map(product => (
            <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden transform transition hover:scale-105">
              <div className="relative">
                <img src={product.image} alt={product.name} className="w-full h-64 object-cover" />
                {product.discount > 0 && (
                  <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded">
                    خصم {product.discount}%
                  </div>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                <p className="text-gray-600 mb-2">{product.description}</p>
                <div className="flex items-center mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating)
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                  <span className="text-sm text-gray-600 mr-1">({product.rating})</span>
                </div>
                <div className="flex justify-between items-center">
                  <div>
                    {product.discount > 0 ? (
                      <>
                        <span className="font-bold text-lg text-red-500">
                          {product.price * (1 - product.discount / 100)} ج.م
                        </span>
                        <span className="text-sm text-gray-500 line-through mr-2">
                          {product.price} ج.م
                        </span>
                      </>
                    ) : (
                      <span className="font-bold text-lg">{product.price} ج.م</span>
                    )}
                  </div>
                  <Link
                    to={`/products/${product.id}`}
                    className="bg-gray-900 text-white px-4 py-2 rounded hover:bg-gray-800 transition"
                  >
                    عرض التفاصيل
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Special Offers */}
      {discountedProducts.length > 0 && (
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8">عروض خاصة</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {discountedProducts.map(product => (
              <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden transform transition hover:scale-105">
                <div className="relative">
                  <img src={product.image} alt={product.name} className="w-full h-64 object-cover" />
                  <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded">
                    خصم {product.discount}%
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-bold text-lg text-red-500">
                        {product.price * (1 - product.discount / 100)} ج.م
                      </span>
                      <span className="text-sm text-gray-500 line-through mr-2">
                        {product.price} ج.م
                      </span>
                    </div>
                    <Link
                      to={`/products/${product.id}`}
                      className="bg-gray-900 text-white px-4 py-2 rounded hover:bg-gray-800 transition"
                    >
                      عرض التفاصيل
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="text-center mt-8">
        <Link
          to="/products"
          className="inline-block bg-gray-900 text-white px-8 py-3 rounded-lg font-semibold hover:bg-gray-800 transition"
        >
          عرض جميع المنتجات
        </Link>
      </div>
    </div>
  );
}