export interface ShippingRate {
  governorate: string;
  cost: number;
  estimatedDays: string;
}

export const shippingRates: ShippingRate[] = [
  { governorate: 'القاهرة', cost: 30, estimatedDays: '1-2' },
  { governorate: 'الجيزة', cost: 30, estimatedDays: '1-2' },
  { governorate: 'الإسكندرية', cost: 45, estimatedDays: '2-3' },
  { governorate: 'المنوفية', cost: 35, estimatedDays: '1-2' },
  { governorate: 'الغربية', cost: 40, estimatedDays: '2-3' },
  { governorate: 'الشرقية', cost: 40, estimatedDays: '2-3' },
  { governorate: 'القليوبية', cost: 35, estimatedDays: '1-2' },
  { governorate: 'الدقهلية', cost: 45, estimatedDays: '2-3' },
  { governorate: 'البحيرة', cost: 45, estimatedDays: '2-3' },
  { governorate: 'كفر الشيخ', cost: 45, estimatedDays: '2-3' },
  { governorate: 'المنيا', cost: 50, estimatedDays: '3-4' },
  { governorate: 'أسيوط', cost: 55, estimatedDays: '3-4' },
  { governorate: 'سوهاج', cost: 55, estimatedDays: '3-4' },
  { governorate: 'الأقصر', cost: 60, estimatedDays: '4-5' },
  { governorate: 'أسوان', cost: 65, estimatedDays: '4-5' },
  { governorate: 'بورسعيد', cost: 45, estimatedDays: '2-3' },
  { governorate: 'الإسماعيلية', cost: 45, estimatedDays: '2-3' },
  { governorate: 'السويس', cost: 45, estimatedDays: '2-3' },
  { governorate: 'دمياط', cost: 45, estimatedDays: '2-3' },
  { governorate: 'الفيوم', cost: 45, estimatedDays: '2-3' },
  { governorate: 'بني سويف', cost: 50, estimatedDays: '3-4' },
  { governorate: 'مطروح', cost: 65, estimatedDays: '4-5' },
  { governorate: 'شمال سيناء', cost: 70, estimatedDays: '4-5' },
  { governorate: 'جنوب سيناء', cost: 70, estimatedDays: '4-5' },
  { governorate: 'البحر الأحمر', cost: 60, estimatedDays: '3-4' },
  { governorate: 'الوادي الجديد', cost: 70, estimatedDays: '4-5' }
];