import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const { items } = useCart();
  const location = useLocation();
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="bg-black shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="text-2xl font-bold text-olive-600">
              AAAMO
            </Link>
          </div>
          
          <div className="flex items-center space-x-8">
            <Link 
              to="/" 
              className={`text-olive-600 hover:text-olive-700 ${location.pathname === '/' ? 'font-bold' : ''}`}
            >
              الرئيسية
            </Link>
            <Link 
              to="/products" 
              className={`text-olive-600 hover:text-olive-700 ${location.pathname === '/products' ? 'font-bold' : ''}`}
            >
              المنتجات
            </Link>
            <Link to="/cart" className="relative text-olive-600 hover:text-olive-700">
              <ShoppingCart className="h-6 w-6" />
              {itemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  {itemCount}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}